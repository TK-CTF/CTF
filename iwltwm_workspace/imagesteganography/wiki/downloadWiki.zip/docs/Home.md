**Project Description**
'Image Steganography' allows you to embed text and files into images, with optional encryption.

**+Latest Release: 1.5.2+**

In this update:

* Improved Error Reporting system, to try and find a bug in that affects the enlarge and difference algorithms
* Minor Bug fixes

**+Release: 1.5.1+**

In this update:

* New 'Feedback' feature
* New Installer (Auto update from previous versions may be affected)

**+NOTE: This version and all of the application releases from now on run on .NET 4.0!!! Please make sure that this is installed for the application to run correctly! .NET 4.0 can be downloaded [here](http://www.microsoft.com/downloads/en/details.aspx?FamilyID=9cfb2d51-5ff4-4491-b0e5-b386f32c0992&displaylang=en).+**

**+Changes in 1.5+**

* **MAJOR** speed improvement for the 'Enlarge' algorithm
* New algorithm; 'Embed' - fast, and almost completely undetectable
* 'Capacity' feature - displays the data capacity for an image, and shows whether the data can be encoded
* Image Scaling - if the data capacity for the image is too small, the image can be resized to allow for more data
* Various Bug Fixes and UI improvements

For information and instructions for use, please see [Documentation](http://imagesteganography.codeplex.com/documentation).

If you have any queries, new feature ideas, or problems, please leave a comment.

Other Applications developed by me:

* [FileShred](http://fileshred.codeplex.com/)
* [Folder Bookmarks](http://cpascoebookmarks.codeplex.com/)
* [Encrypted Notes](http://cpascoeenotes.codeplex.com/)

Screen shot:

[Image: Image Steganography Screen shot.png)(Image_-Image-Steganography-Screen-shot.png)

**+To do+**
* Fix the application self-update