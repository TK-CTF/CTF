## **+Information+**

Image Steganography uses two methods to embed files and text into images:

1) Difference - the 'Difference' mode will output a seemingly identical image to the original input image, but this is the most noticeable mode (and thus I might remove it at a later date). By using the two images (the processed image and the original image), the 'Difference' mode compares each pixel, computes the difference, and turns it back into a byte.

2) Enlarge - the 'Enlarge' mode outputs an image 4 times bigger than the input image (2 x Width, 2 x Height). By doing this, it can has 3 times the data capacity of the 'Difference' mode, and the original image isn't required (and so this mode is the default).

3) Embed - the 'Embed' mode will output an almost identical image to the input image. It encodes the data in the last two bits of the red and Blue colour channels; but by doing this, only has half a byte per pixel.

The Overall capacity of an image will depend on the algorithm, but the capacity can be increased by Scaling the Image (See Below).



If anyone wants a more technical explanation, please leave a comment.

**Note: The output image will be in a .png format. Do not change it to a lossy storage format like .jgp, or the data will be lost.**

## **+Encoding+**

To Encode some text or a file:

1) Select the 'Encode' option, and select the encoding mode (Difference or Enlarge).
2) Drag-and-drop an image file into the text box labelled 'Image'.
3a) To encode a file, check the 'File' option, the text box will turn white (enabled). Drag and drop a file into the text box, and the location will be displayed _(Note: The file name is embedded along with the data)_
3b) To encode some text, check the 'Text' option, and enter the desired text into the large text box.
4) Finally, choose a suitable name and location for the output file, and click 'Start'

## **+Decoding+**

To Decode the text or file:

1) Select the 'Decode' option, and select the encoding mode (Difference or Enlarge).
2a) If 'Enlarge' mode is selected, Drag-and-drop the image file into the text box labelled 'Image'.
2b) If 'Difference' mode is selected, Drag-and-drop the image with the embedded data into the 'Image' text box, and the original image into 'Image 2' text box (it doesn't really matter which one)
3a) If the image is known to contain a file, select the 'Output to File' option, and choose a folder to save the file to _(as mentioned earlier, the file name is embedded along with the data. If the file already exists, you will be asked to save the file under another name or location)_
3b) If the image is know to contain text, select the 'Output Text' option; the output text will be displayed in the text box.
4) Click the 'Start' button to start the decoding process.

## **+Encryption+**

The software supports AES encryption of the data before embedding it in an image. 

To use, simply check the 'Encrypt' check box and encode/decode an image. When encoding, you will be prompted to set a password before the encoding process begins. When decoding, you will be prompted to enter the password after the decoding process has finished. _(Note: If a file has been encrypted, if you don't check the 'Encrypt' check box or enter a password when decoding, the application will throw an error: 'Error - Can't find the file name. The data could be corrupt, in a text format, or it could be encrypted.' It's nothing bad, it just means it could contain encrypted data)_

## **+Image Scaling+**

If the length of the data exceeds the image data capacity, a check box labelled 'Pre-Scale Image' will be shown:

[Image:227021)(Image_227021)

If you click 'Start' and this check box is checked, the image will be scaled up 4 times larger (2 x Width, 2 x Height), allowing for more data to be stored; but it takes a bit more time to encode the data into the image.

## **+Demo+**

A simple demonstration: [Demo Image](Documentation_Demo Image)(Demo-Image.png)

Download the image of a tree, start Image Steganography, go to 'Decode', make sure the 'Embed' mode is set, choose somewhere to output the file (another image of some trees) and click 'Start'.